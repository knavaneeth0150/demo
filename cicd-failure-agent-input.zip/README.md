CI/CD Failure Analysis Agent - Initial Assessment Input

This ZIP contains pipeline logs, configuration snapshot, and recent changes.
The agent uses this data to identify failure stage, extract errors, and assess context.